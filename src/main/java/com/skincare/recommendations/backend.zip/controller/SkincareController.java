package com.skincare.recommendations.controller;

import com.skincare.recommendations.dto.RecommendationsResponse;
import com.skincare.recommendations.model.Recommendation;
import com.skincare.recommendations.repository.RecommendationRepository;
import com.skincare.recommendations.repository.UserProductRecommendationRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.Stream;

@RestController
@RequestMapping("/api/skincare")
public class SkincareController {

    private final RecommendationRepository recommendationRepository;
    private final UserProductRecommendationRepository userRepo;

    @Autowired
    public SkincareController(RecommendationRepository recommendationRepository,
                              UserProductRecommendationRepository userRepo) {
        this.recommendationRepository = recommendationRepository;
        this.userRepo = userRepo;
    }

    @GetMapping("/recommendations")
    public RecommendationsResponse getRecommendations(@RequestParam String skinType,
                                                      @RequestParam List<String> concerns) {
        // 1) Default recommendations (from recommendation_recommendations table)
        List<String> defaultRecs = new ArrayList<>();
        Recommendation rec = recommendationRepository.findBySkinType(skinType);
        if (rec != null && rec.getRecommendations() != null) {
            defaultRecs = concerns.stream()
                .flatMap(concern -> {
                    String recString = rec.getRecommendations().get(concern); // comma-separated string
                    if (recString != null && !recString.isBlank()) {
                        return Arrays.stream(recString.split(","))
                                     .map(String::trim);
                    } else {
                        return Stream.empty();
                    }
                })
                .distinct()
                .collect(Collectors.toList());
        }

        // 2) Community recommendations (only those matching the selection)
        List<String> communityRecs = concerns.stream()
            .flatMap(concern -> userRepo.findBySkinTypeAndConcerns(skinType, concern).stream()
                .map(userRec -> {
                    String brand = Optional.ofNullable(userRec.getBrandName()).orElse("").trim();
                    String product = Optional.ofNullable(userRec.getProductName()).orElse("").trim();
                    String type = Optional.ofNullable(userRec.getProductType()).orElse("").trim();
                    String formatted = (brand + " " + product).trim();
                    if (!type.isEmpty()) formatted += " (" + type + ")";
                    return formatted;
                })
            )
            .distinct()
            .collect(Collectors.toList());

        return new RecommendationsResponse(defaultRecs, communityRecs);
    }
}
