// UserProductRecommendationRepository.java
package com.skincare.recommendations.repository;

import com.skincare.recommendations.model.UserProductRecommendation;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface UserProductRecommendationRepository extends JpaRepository<UserProductRecommendation, Long> {

    // Custom query to find recommendations where the concerns string contains a given concern
    @Query("SELECT r FROM UserProductRecommendation r WHERE r.skinType = :skinType AND r.concerns LIKE CONCAT('%', :concern, '%')")
    List<UserProductRecommendation> findBySkinTypeAndConcerns(String skinType, String concern);
}