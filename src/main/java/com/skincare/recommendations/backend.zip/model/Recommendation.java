package com.skincare.recommendations.model;

import jakarta.persistence.*;
import java.util.Map;

@Entity
@Table(name = "recommendation")
public class Recommendation {

    @Id
    @Column(name = "skin_type")   // ✅ maps to DB column
    private String skinType;

    @ElementCollection
    @CollectionTable(
        name = "recommendation_recommendations", // ✅ join table
        joinColumns = @JoinColumn(name = "recommendation_skin_type")
    )
    @MapKeyColumn(name = "recommendations_key")  // concern (e.g., "Acne")
    @Column(name = "recommendations_list")       // comma-separated product list
    private Map<String, String> recommendations; // ✅ each key -> one string

    // --- Getters & Setters ---
    public String getSkinType() {
        return skinType;
    }

    public void setSkinType(String skinType) {
        this.skinType = skinType;
    }

    public Map<String, String> getRecommendations() {
        return recommendations;
    }

    public void setRecommendations(Map<String, String> recommendations) {
        this.recommendations = recommendations;
    }
}
